// Java code to illustrate
// System.out.println();
/*
Author: Alejandro Lopez
Class: CSIS 3810 L01
Started Working on Project: 09/24/2021
Stopped Working on Project: 10/18/2021
 */


import java.io.*;

class GFG {
    public static void main(String[] args)
    {
        MainMemory mm = new MainMemory();
        mm.SharkOS();
    }
}
